./GUISample --pos 1 --robname GUISample1 &
./GUISample --pos 2 --robname GUISample2 &
./GUISample --pos 3 --robname GUISample3 &
./GUISample --pos 4 --robname GUISample4 &
./GUISample --pos 5 --robname GUISample5 &
