java jClient  --pos 1 --robname jClient1 "$@"
