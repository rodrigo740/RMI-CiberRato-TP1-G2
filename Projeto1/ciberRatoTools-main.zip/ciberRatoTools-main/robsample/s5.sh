./robsample --pos 1 --robname "R1" &
./robsample --pos 2 --robname "R2" &
./robsample --pos 3 --robname "R3" &
./robsample --pos 4 --robname "R4" &
./robsample --pos 5 --robname "R5" & 
