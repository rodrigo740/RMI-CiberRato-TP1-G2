./robsample --pos 1 --robname "R1" "$@" 
